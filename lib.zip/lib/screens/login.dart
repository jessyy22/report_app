import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../services/fcm_service.dart';
import 'account_status_screen.dart';
import 'register.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _isLoading = false;
  bool _isPasswordVisible = false;
  bool _resetting = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _handleSignIn() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    final client = Supabase.instance.client;

    try {
      // ============================================================
      // 1. AUTHENTICATE
      // ============================================================

      final response = await client.auth.signInWithPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text,
      );

      final user = response.user;

      if (user == null) {
        throw const AuthException('Authentication failed.');
      }

      debugPrint('LOGIN USER: ${user.id}');

      // ============================================================
      // 2. GET USER ROLE
      // ============================================================

      final roleData = await client
          .from('user_roles')
          .select('role')
          .eq('id', user.id)
          .maybeSingle();

      if (roleData == null) {
        await client.auth.signOut();

        throw const AuthException(
          'Your RTODA account role could not be found. '
          'Please contact support.',
        );
      }

      final role = (roleData['role'] ?? '').toString().trim().toLowerCase();

      debugPrint('LOGIN ROLE: $role');

      // ============================================================
      // 3. EMAIL VERIFICATION
      // ============================================================

      final isNewAuthFlow = user.userMetadata?['rtoda_auth_v2'] == true;

      if (isNewAuthFlow && user.emailConfirmedAt == null) {
        await client.auth.signOut();

        if (!mounted) return;

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => EmailNotVerifiedLoginScreen(
              email: user.email ?? _emailController.text.trim(),
            ),
          ),
        );

        return;
      }

      // ============================================================
      // 4. COMPLETE PENDING UPLOADS
      // ============================================================

      await _finishPendingUploads(user.id, role);

      // ============================================================
      // 5. DRIVER LOGIN
      // ============================================================

      if (role == 'driver') {
        debugPrint('Checking driver profile...');
        debugPrint('Driver UID: ${user.id}');

        final data = await client
            .from('driver_profiles')
            .select(
              'id, full_name, license_number, body_number, '
              'is_active, rating, created_at, '
              'profile_photo_url, license_photo_url, '
              'phone_number, verification_status',
            )
            .eq('id', user.id)
            .maybeSingle();

        debugPrint('DRIVER PROFILE: $data');

        // ----------------------------------------------------------
        // DRIVER PROFILE NOT FOUND
        // ----------------------------------------------------------

        if (data == null) {
          await client.auth.signOut();

          if (!mounted) return;

          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Driver profile not found. Please contact support.',
              ),
              backgroundColor: Colors.red,
            ),
          );

          return;
        }

        // ----------------------------------------------------------
        // ACTIVE STATUS
        // ----------------------------------------------------------

        final isActive = data['is_active'] == true;

        debugPrint('DRIVER ACTIVE: $isActive');

        if (!isActive) {
          await client.auth.signOut();

          if (!mounted) return;

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => const AccountStatusScreen(status: 'inactive'),
            ),
          );

          return;
        }

        // ----------------------------------------------------------
        // VERIFICATION STATUS
        // ----------------------------------------------------------

        final verificationStatus = _driverStatus(data);

        debugPrint('DRIVER VERIFICATION STATUS: $verificationStatus');

        if (verificationStatus != 'approved') {
          await client.auth.signOut();

          if (!mounted) return;

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => AccountStatusScreen(status: verificationStatus),
            ),
          );

          return;
        }

        // ----------------------------------------------------------
        // REGISTER FCM DEVICE
        // ----------------------------------------------------------

        try {
          await FcmService().initialize();
          debugPrint('FCM initialized for driver.');
        } catch (e) {
          debugPrint('FCM initialization failed: $e');
        }

        // ----------------------------------------------------------
        // DRIVER APPROVED
        // ----------------------------------------------------------

        if (!mounted) return;

        Navigator.pushReplacementNamed(context, '/driver_dashboard');

        return;
      }

      // ============================================================
      // 6. COMMUTER LOGIN
      // ============================================================

      if (role == 'commuter') {
        if (isNewAuthFlow) {
          await client
              .from('commuter_profiles')
              .update({'is_verified': true})
              .eq('id', user.id);
        }

        // Register FCM device
        try {
          await FcmService().initialize();
          debugPrint('FCM initialized for commuter.');
        } catch (e) {
          debugPrint('FCM initialization failed: $e');
        }

        if (!mounted) return;

        Navigator.pushReplacementNamed(context, '/navigation_bar');

        return;
      }

      // ============================================================
      // 7. UNKNOWN ROLE
      // ============================================================

      await client.auth.signOut();

      throw const AuthException(
        'Unknown account role. Please contact support.',
      );
    } on AuthException catch (e) {
      debugPrint('AUTH ERROR: ${e.message}');

      if (!mounted) return;

      final msg = e.message.toLowerCase().contains('email not confirmed')
          ? 'Please verify your email before logging in.'
          : e.message;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(msg), backgroundColor: Colors.red));
    } catch (e, stackTrace) {
      debugPrint('LOGIN ERROR: $e');
      debugPrint('STACK TRACE: $stackTrace');

      try {
        await client.auth.signOut();
      } catch (_) {}

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Login failed: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  // ================================================================
  // DRIVER STATUS
  // ================================================================

  String _driverStatus(Map<String, dynamic>? data) {
    if (data == null) {
      return 'pending';
    }

    final status = data['verification_status']?.toString().trim().toLowerCase();

    if (status == 'approved' || status == 'pending' || status == 'rejected') {
      return status!;
    }

    // Backward compatibility:
    // Existing drivers with no verification status
    // can still use is_active.
    if (data['is_active'] == true) {
      return 'approved';
    }

    return 'pending';
  }

  // ================================================================
  // REFRESH DRIVER STATUS
  // ================================================================

  Future<void> _refreshDriverStatus(String uid) async {
    final client = Supabase.instance.client;

    try {
      final data = await client
          .from('driver_profiles')
          .select(
            'id, full_name, license_number, body_number, '
            'is_active, rating, created_at, '
            'profile_photo_url, license_photo_url, '
            'phone_number, verification_status',
          )
          .eq('id', uid)
          .maybeSingle();

      if (data == null) {
        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Driver profile not found.'),
            backgroundColor: Colors.red,
          ),
        );

        return;
      }

      final status = _driverStatus(data);

      if (!mounted) return;

      if (status == 'approved' && data['is_active'] == true) {
        Navigator.pushReplacementNamed(context, '/driver_dashboard');
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => AccountStatusScreen(status: status),
          ),
        );
      }
    } catch (e, stackTrace) {
      debugPrint('Refresh driver status error: $e');
      debugPrint('STACK TRACE: $stackTrace');

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Unable to check account status: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // ================================================================
  // PENDING UPLOADS
  // ================================================================

  Future<void> _finishPendingUploads(String uid, String role) async {
    final prefs = await SharedPreferences.getInstance();

    final pendingUid = prefs.getString('pending_registration_uid');

    if (pendingUid != uid) return;

    final profilePath = prefs.getString('pending_profile_image_path');

    final idPath = prefs.getString('pending_id_image_path');

    final client = Supabase.instance.client;

    // --------------------------------------------------------------
    // PROFILE PHOTO
    // --------------------------------------------------------------

    if (profilePath != null && File(profilePath).existsSync()) {
      final ext = profilePath.split('.').last.toLowerCase();

      final storagePath =
          '${role == 'driver' ? 'drivers' : 'commuters'}/$uid.$ext';

      await client.storage
          .from('user_profiles')
          .upload(
            storagePath,
            File(profilePath),
            fileOptions: const FileOptions(upsert: true),
          );

      final url = client.storage
          .from('user_profiles')
          .getPublicUrl(storagePath);

      if (role == 'driver') {
        await client
            .from('driver_profiles')
            .update({'profile_photo_url': url})
            .eq('id', uid);
      } else {
        await client
            .from('commuter_profiles')
            .update({'profile_photo_url': url})
            .eq('id', uid);
      }
    }

    // --------------------------------------------------------------
    // ID / LICENSE PHOTO
    // --------------------------------------------------------------

    if (idPath != null && File(idPath).existsSync()) {
      final ext = idPath.split('.').last.toLowerCase();

      final storagePath =
          '${role == 'driver' ? 'drivers_license' : 'commuter_ids'}/$uid.$ext';

      await client.storage
          .from('id-verifications')
          .upload(
            storagePath,
            File(idPath),
            fileOptions: const FileOptions(upsert: true),
          );

      final url = client.storage
          .from('id-verifications')
          .getPublicUrl(storagePath);

      if (role == 'driver') {
        await client
            .from('driver_profiles')
            .update({'license_photo_url': url})
            .eq('id', uid);
      } else {
        await client
            .from('commuter_profiles')
            .update({'id_photo_url': url})
            .eq('id', uid);
      }
    }

    // --------------------------------------------------------------
    // CLEAR PENDING DATA
    // --------------------------------------------------------------

    await prefs.remove('pending_registration_uid');

    await prefs.remove('pending_registration_role');

    await prefs.remove('pending_profile_image_path');

    await prefs.remove('pending_id_image_path');
  }

  // ================================================================
  // FORGOT PASSWORD
  // ================================================================

  Future<void> _forgotPassword() async {
    final email = _emailController.text.trim();

    if (!email.contains('@')) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Enter your email first.')));

      return;
    }

    setState(() => _resetting = true);

    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(email);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password reset email sent.')),
      );
    } on AuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _resetting = false);
      }
    }
  }

  // ================================================================
  // UI
  // ================================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8F7),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                Image.asset(
                  'assets/images/app_icon.png',
                  width: 90,
                  height: 90,
                ),

                const SizedBox(height: 14),

                const Text(
                  'RTODA Vigan',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: Colors.green,
                  ),
                ),

                const SizedBox(height: 6),

                const Text(
                  'Report • Monitor • Protect',
                  style: TextStyle(color: Colors.black54),
                ),

                const SizedBox(height: 28),

                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.black12),
                  ),
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        validator: (v) =>
                            v == null ||
                                !RegExp(
                                  r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
                                ).hasMatch(v.trim())
                            ? 'Enter a valid email'
                            : null,
                        decoration: _input('Email', Icons.email_outlined),
                      ),

                      const SizedBox(height: 16),

                      TextFormField(
                        controller: _passwordController,
                        obscureText: !_isPasswordVisible,
                        validator: (v) => v == null || v.isEmpty
                            ? 'Password is required'
                            : null,
                        decoration: _input(
                          'Password',
                          Icons.lock_outline,
                          suffix: IconButton(
                            onPressed: () {
                              setState(() {
                                _isPasswordVisible = !_isPasswordVisible;
                              });
                            },
                            icon: Icon(
                              _isPasswordVisible
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                          ),
                        ),
                      ),

                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: _resetting ? null : _forgotPassword,
                          child: Text(
                            _resetting ? 'Sending...' : 'Forgot password?',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 18),

                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _handleSignIn,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text(
                            'LOGIN',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                  ),
                ),

                TextButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SignupPage()),
                  ),
                  child: const Text("Don't have an account? Create one"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _input(String label, IconData icon, {Widget? suffix}) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      suffixIcon: suffix,
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Colors.black12),
      ),
    );
  }
}

// ==================================================================
// EMAIL NOT VERIFIED
// ==================================================================

class EmailNotVerifiedLoginScreen extends StatelessWidget {
  final String email;

  const EmailNotVerifiedLoginScreen({super.key, required this.email});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8F7),
      appBar: AppBar(
        title: const Text('Email Verification'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.mark_email_unread_rounded,
                size: 70,
                color: Colors.green,
              ),

              const SizedBox(height: 20),

              const Text(
                'Verify your email first',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800),
              ),

              const SizedBox(height: 10),

              Text(
                'Please verify $email using the confirmation link before logging in.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black54, height: 1.5),
              ),

              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: () =>
                      Navigator.pushReplacementNamed(context, '/login'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text('BACK TO LOGIN'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
