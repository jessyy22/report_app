import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'email_verification_screen.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});
  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _name = TextEditingController();
  final _body = TextEditingController();
  final _license = TextEditingController();
  final _phone = TextEditingController();

  bool _driver = true, _loading = false, _showPass = false;
  File? _profile, _id;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _name.dispose();
    _body.dispose();
    _license.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _pick(bool profile) async {
    final source = await showDialog<ImageSource>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Select Image Source'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, ImageSource.camera),
            child: const Text('Camera'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, ImageSource.gallery),
            child: const Text('Gallery'),
          ),
        ],
      ),
    );

    if (source == null) return;

    final image = await ImagePicker().pickImage(
      source: source,
      imageQuality: 80,
    );

    if (image == null || !mounted) return;

    setState(() {
      if (profile) {
        _profile = File(image.path);
      } else {
        _id = File(image.path);
      }
    });
  }

  Future<void> _signup() async {
    if (!_formKey.currentState!.validate()) return;

    if (_profile == null || _id == null) {
      _error('Please select both required photos.');
      return;
    }

    setState(() => _loading = true);
    final supabase = Supabase.instance.client;

    try {
      final role = _driver ? 'driver' : 'commuter';

      final response = await supabase.auth.signUp(
        email: _email.text.trim(),
        password: _password.text,
        data: {
          'rtoda_auth_v2': true,
          'role': role,
          'full_name': _name.text.trim(),
          'phone_number': _phone.text.trim(),
          'body_number': _body.text.trim(),
          'license_number': _license.text.trim(),
        },
      );

      final user = response.user;
      if (user == null) {
        throw const AuthException('Unable to create the account.');
      }

      final prefs = await SharedPreferences.getInstance();

      await prefs.setString('pending_registration_uid', user.id);
      await prefs.setString('pending_registration_role', role);
      await prefs.setString('pending_profile_image_path', _profile!.path);
      await prefs.setString('pending_id_image_path', _id!.path);

      if (supabase.auth.currentSession != null) {
        await _completeProfile(user.id, role);
      }

      if (!mounted) return;

      if (response.session == null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => EmailVerificationScreen(email: _email.text.trim()),
          ),
        );
      } else {
        Navigator.pushReplacementNamed(
          context,
          _driver ? '/driver_dashboard' : '/navigation_bar',
        );
      }
    } on AuthException catch (e) {
      _error(e.message);
    } catch (e) {
      _error('Registration failed: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _completeProfile(String uid, String role) async {
    final supabase = Supabase.instance.client;
    final prefs = await SharedPreferences.getInstance();

    final profilePath = prefs.getString('pending_profile_image_path');
    final idPath = prefs.getString('pending_id_image_path');

    final table = role == 'driver' ? 'driver_profiles' : 'commuter_profiles';

    // PROFILE PHOTO
    if (profilePath != null && File(profilePath).existsSync()) {
      final ext = profilePath.split('.').last.toLowerCase();
      final path = '${role == 'driver' ? 'drivers' : 'commuters'}/$uid.$ext';

      await supabase.storage
          .from('user_profiles')
          .upload(
            path,
            File(profilePath),
            fileOptions: const FileOptions(upsert: true),
          );

      final url = supabase.storage.from('user_profiles').getPublicUrl(path);

      await supabase
          .from(table)
          .update({'profile_photo_url': url})
          .eq('id', uid);
    }

    // ID / LICENSE PHOTO
    if (idPath != null && File(idPath).existsSync()) {
      final ext = idPath.split('.').last.toLowerCase();

      final path =
          '${role == 'driver' ? 'drivers_license' : 'commuter_ids'}/$uid.$ext';

      await supabase.storage
          .from('id-verifications')
          .upload(
            path,
            File(idPath),
            fileOptions: const FileOptions(upsert: true),
          );

      final url = supabase.storage.from('id-verifications').getPublicUrl(path);

      await supabase
          .from(table)
          .update(
            role == 'driver'
                ? {'license_photo_url': url}
                : {'id_photo_url': url},
          )
          .eq('id', uid);
    }

    await prefs.remove('pending_registration_uid');
    await prefs.remove('pending_registration_role');
    await prefs.remove('pending_profile_image_path');
    await prefs.remove('pending_id_image_path');
  }

  void _error(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8F7),
      appBar: AppBar(
        title: const Text('Create Account'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _role(
                      'Driver',
                      _driver,
                      () => setState(() => _driver = true),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _role(
                      'Commuter',
                      !_driver,
                      () => setState(() => _driver = false),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              Text(
                _driver
                    ? 'Driver accounts require RTODA/LGU verification.'
                    : 'Commuter accounts are activated after email verification.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black54),
              ),

              const SizedBox(height: 20),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _image('Profile', _profile, () => _pick(true)),
                  _image(_driver ? 'License' : 'ID', _id, () => _pick(false)),
                ],
              ),

              const SizedBox(height: 24),

              _field(_name, 'Full Name', Icons.person_outline),
              const SizedBox(height: 16),

              // PHONE NUMBER FOR BOTH ROLES
              _field(
                _phone,
                'Phone Number',
                Icons.phone_outlined,
                number: true,
              ),

              if (_driver) ...[
                const SizedBox(height: 16),
                _field(
                  _body,
                  'Body Number (VGN-XXX)',
                  Icons.directions_bus_outlined,
                ),
                const SizedBox(height: 16),
                _field(_license, 'License Number', Icons.badge_outlined),
              ],

              const SizedBox(height: 16),

              _field(
                _email,
                'Email',
                Icons.email_outlined,
                keyboard: TextInputType.emailAddress,
              ),

              const SizedBox(height: 16),

              _field(_password, 'Password', Icons.lock_outline, obscure: true),

              const SizedBox(height: 28),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: _loading ? null : _signup,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: _loading
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Text(
                          'CREATE ACCOUNT',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _role(String title, bool selected, VoidCallback tap) {
    return InkWell(
      onTap: tap,
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: selected ? Colors.green.withOpacity(.1) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? Colors.green : Colors.black12,
            width: selected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Icon(
              title == 'Driver' ? Icons.local_taxi : Icons.person,
              color: selected ? Colors.green : Colors.black45,
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                fontWeight: selected ? FontWeight.bold : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _image(String label, File? file, VoidCallback tap) {
    return Column(
      children: [
        InkWell(
          onTap: tap,
          borderRadius: BorderRadius.circular(18),
          child: Container(
            width: 120,
            height: 110,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.black12),
            ),
            child: file == null
                ? const Icon(
                    Icons.add_a_photo_outlined,
                    size: 34,
                    color: Colors.green,
                  )
                : ClipRRect(
                    borderRadius: BorderRadius.circular(17),
                    child: Image.file(
                      file,
                      fit: BoxFit.cover,
                      width: 120,
                      height: 110,
                    ),
                  ),
          ),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
      ],
    );
  }

  Widget _field(
    TextEditingController controller,
    String label,
    IconData icon, {
    bool obscure = false,
    bool number = false,
    TextInputType? keyboard,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscure && !_showPass,
      keyboardType:
          keyboard ?? (number ? TextInputType.phone : TextInputType.text),
      validator: (value) {
        if (value == null || value.trim().isEmpty) {
          return '$label is required';
        }

        if (label == 'Email' &&
            !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value.trim())) {
          return 'Enter a valid email';
        }

        if (label == 'Password' && value.length < 8) {
          return 'Use at least 8 characters';
        }

        if (label == 'Phone Number' &&
            !RegExp(r'^(09|\+639)\d{9}$').hasMatch(value.trim())) {
          return 'Enter a valid Philippine phone number';
        }

        return null;
      },
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        suffixIcon: obscure
            ? IconButton(
                onPressed: () => setState(() => _showPass = !_showPass),
                icon: Icon(_showPass ? Icons.visibility : Icons.visibility_off),
              )
            : null,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.black12),
        ),
      ),
    );
  }
}
