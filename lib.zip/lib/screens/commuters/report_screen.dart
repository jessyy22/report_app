import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/notification_service.dart';

class ReportForm extends StatefulWidget {
  const ReportForm({super.key});
  @override
  State<ReportForm> createState() => _ReportFormState();
}

enum ReportType { reportNow, lateReport }

class _ReportFormState extends State<ReportForm> {
  final _formKey = GlobalKey<FormState>();
  final _date = TextEditingController(), _time = TextEditingController();
  final _driver = TextEditingController(), _location = TextEditingController();
  final _name = TextEditingController(), _address = TextEditingController();
  final _contact = TextEditingController(), _body = TextEditingController();
  final _lateReason = TextEditingController();
  final _picker = ImagePicker();

  String _tricycleId = '', _bodyError = '';
  String? _selectedItem;
  bool _loadingProfile = true,
      _searching = false,
      _uploading = false,
      _locating = false;
  File? _image;
  double? _lat, _lng;
  ReportType _reportType = ReportType.reportNow;

  final items = [
    'Overcharging',
    'Abuse',
    'Discriminate / Refusal to convey',
    'Discourteous / Arrogant Driver',
    'Overloading',
    'Illegal Parking',
    'No Mayors Permit',
    'No Drivers Permit',
    'Others',
  ];

  @override
  void initState() {
    super.initState();
    _setDateTime();
    _loadProfile();
    _getLocation();
  }

  // Exact commuter_profiles columns used here:
  // id, full_name, id_photo_url, is_verified, created_at,
  // profile_photo_url, phone_number
  Future<void> _loadProfile() async {
    final db = Supabase.instance.client;
    final user = db.auth.currentUser;
    if (user == null) {
      if (mounted) setState(() => _loadingProfile = false);
      return;
    }
    try {
      final data = await db
          .from('commuter_profiles')
          .select('id, full_name, phone_number')
          .eq('id', user.id)
          .maybeSingle();
      if (!mounted) return;
      if (data == null) {
        setState(() => _loadingProfile = false);
        _show('No commuter profile was found for this account.', error: true);
        return;
      }
      _name.text = (data['full_name'] ?? '').toString();
      _contact.text = (data['phone_number'] ?? '').toString();
      setState(() => _loadingProfile = false);
    } catch (e) {
      debugPrint('Profile error: $e');
      if (mounted) {
        setState(() => _loadingProfile = false);
        _show('Unable to load commuter information.', error: true);
      }
    }
  }

  void _setDateTime() {
    final n = DateTime.now();
    _date.text = DateFormat('yyyy-MM-dd').format(n);
    _time.text = DateFormat('hh:mm a').format(n);
  }

  Future<void> _getLocation() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return;
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied)
        p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied ||
          p == LocationPermission.deniedForever)
        return;
      final x = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      _lat = x.latitude;
      _lng = x.longitude;
      final places = await placemarkFromCoordinates(x.latitude, x.longitude);
      if (!mounted || places.isEmpty) return;
      final pmark = places.first;
      setState(
        () => _location.text = [
          pmark.street,
          pmark.locality,
          pmark.administrativeArea,
        ].where((x) => x != null && x!.trim().isNotEmpty).join(', '),
      );
    } catch (e) {
      debugPrint('Location error: $e');
    }
  }

  Future<void> _lookupDriver(String value) async {
    final body = value.trim().toUpperCase();
    if (body.isEmpty) {
      setState(() => {_tricycleId = '', _driver.clear(), _bodyError = ''});
      return;
    }
    if (!RegExp(r'^(VGN|BTY)-\d+$').hasMatch(body)) {
      setState(
        () => {
          _bodyError = 'Use format VGN-123 or BTY-123',
          _driver.clear(),
          _tricycleId = '',
        },
      );
      return;
    }
    setState(() => {_searching = true, _bodyError = ''});
    try {
      final db = Supabase.instance.client;
      final t = await db
          .from('tricycles')
          .select('tricycle_id, body_number')
          .eq('body_number', body)
          .maybeSingle();
      if (t == null) {
        setState(
          () => {
            _bodyError = 'Body number not found in database.',
            _driver.clear(),
            _tricycleId = '',
          },
        );
      } else {
        String? name;
        final d = await db
            .from('drivers')
            .select('name')
            .eq('tricycle_id', t['tricycle_id'])
            .maybeSingle();
        if (d?['name'] != null)
          name = d!['name'].toString();
        else {
          final p = await db
              .from('driver_profiles')
              .select('full_name')
              .eq('body_number', body)
              .maybeSingle();
          name = p?['full_name']?.toString();
        }
        setState(
          () => {
            _tricycleId = t['tricycle_id'].toString(),
            _driver.text = name ?? 'Unassigned Driver',
            _bodyError = '',
          },
        );
      }
    } catch (e) {
      debugPrint('Driver lookup error: $e');
      if (mounted) setState(() => _bodyError = 'Database lookup error.');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final f = await _picker.pickImage(source: source, imageQuality: 80);
      if (f != null && mounted) setState(() => _image = File(f.path));
    } catch (e) {
      _show('Error selecting image: $e', error: true);
    }
  }

  Future<void> _pickLocation() async {
    setState(() => _locating = true);
    try {
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied)
        p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied ||
          p == LocationPermission.deniedForever) {
        _show('Location permission is required.', error: true);
        return;
      }
      if (!mounted) return;
      final r = await Navigator.push<LatLng>(
        context,
        MaterialPageRoute(builder: (_) => const IncidentLocationPicker()),
      );
      if (r == null) return;
      _lat = r.latitude;
      _lng = r.longitude;
      final places = await placemarkFromCoordinates(r.latitude, r.longitude);
      if (!mounted) return;
      setState(
        () => _location.text = places.isNotEmpty
            ? [
                places.first.street,
                places.first.locality,
                places.first.administrativeArea,
              ].where((x) => x != null && x!.trim().isNotEmpty).join(', ')
            : '${r.latitude}, ${r.longitude}',
      );
    } catch (e) {
      _show('Could not retrieve location: $e', error: true);
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_bodyError.isNotEmpty || _tricycleId.isEmpty) {
      _show('Please enter a valid verified body number.', error: true);
      return;
    }
    final db = Supabase.instance.client, user = db.auth.currentUser;
    if (user == null) {
      _show('You must be logged in.', error: true);
      return;
    }
    if (_name.text.trim().isEmpty || _contact.text.trim().isEmpty) {
      await _loadProfile();
      if (_name.text.trim().isEmpty || _contact.text.trim().isEmpty) return;
    }
    setState(() => _uploading = true);
    try {
      String? imageUrl;
      if (_image != null) {
        final ext = _image!.path.split('.').last;
        final path =
            'evidence/${user.id}_${DateTime.now().millisecondsSinceEpoch}.$ext';
        await db.storage
            .from('evidence')
            .upload(
              path,
              _image!,
              fileOptions: const FileOptions(
                cacheControl: '3600',
                upsert: true,
              ),
            );
        imageUrl = db.storage.from('evidence').getPublicUrl(path);
      }
      await db.from('reports').insert({
        'user_id': user.id,
        'body_number': _body.text.trim(),
        'tricycle_id': _tricycleId,
        'violation': _selectedItem,
        'location': _location.text.trim(),
        'incidentdate': _date.text,
        'incidenttime': _time.text,
        'evidence_url': imageUrl,
        'status': 'Pending',
        'complainantname': _name.text.trim(),
        'address': _address.text.trim().isEmpty ? null : _address.text.trim(),
        'contact': _contact.text.trim(),
        'report_type': _reportType == ReportType.reportNow
            ? 'Report Now'
            : 'Late Report',
        'late_report_reason': _reportType == ReportType.lateReport
            ? _lateReason.text.trim()
            : null,
      });
      try {
        await NotificationService.sendPushToRole(
          role: 'admin_staff',
          title: 'New Report Received',
          message:
              'A new ${_selectedItem ?? 'offense'} report was submitted for body number ${_body.text.trim()}.',
          type: 'report',
        );
      } catch (e) {
        debugPrint('Notification error: $e');
      }
      if (!mounted) return;
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          title: const Text('Report Submitted'),
          content: const Text(
            'Your report was submitted successfully and safely logged.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      _reset();
      _setDateTime();
      _getLocation();
    } catch (e) {
      _show('Submission Error: $e', error: true);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  void _reset() {
    _formKey.currentState?.reset();
    setState(() {
      _selectedItem = null;
      _tricycleId = '';
      _bodyError = '';
      _image = null;
      _body.clear();
      _driver.clear();
      _location.clear();
      _date.clear();
      _time.clear();
      _lateReason.clear();
      _lat = null;
      _lng = null;
    });
  }

  Future<void> _pickDate() async {
    if (_reportType == ReportType.reportNow) return;
    final d = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2025),
      lastDate: DateTime.now(),
    );
    if (d != null && mounted)
      setState(() => _date.text = DateFormat('yyyy-MM-dd').format(d));
  }

  Future<void> _pickTime() async {
    if (_reportType == ReportType.reportNow) return;
    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (t != null && mounted) setState(() => _time.text = t.format(context));
  }

  void _show(String text, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor: error ? Colors.redAccent : null,
      ),
    );
  }

  InputDecoration _input(
    String label,
    IconData icon, {
    String? hint,
    Widget? suffix,
  }) => InputDecoration(
    labelText: label,
    hintText: hint,
    prefixIcon: Icon(icon, color: Colors.green),
    suffixIcon: suffix,
    filled: true,
    fillColor: Colors.white,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Color(0xFFE0E0E0)),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Colors.green, width: 2),
    ),
  );

  Widget _header(String text, IconData icon) => Padding(
    padding: const EdgeInsets.only(bottom: 12, top: 4),
    child: Row(
      children: [
        Icon(icon, color: Colors.green),
        const SizedBox(width: 8),
        Text(
          text,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ],
    ),
  );

  @override
  void dispose() {
    for (final c in [
      _date,
      _time,
      _driver,
      _location,
      _name,
      _address,
      _contact,
      _body,
      _lateReason,
    ])
      c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFA),
      appBar: AppBar(
        title: const Text(
          'RTODA Public Complaint Desk',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
        backgroundColor: Colors.green,
      ),
      body: _uploading
          ? const Center(child: CircularProgressIndicator(color: Colors.green))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            _header('Report Type', Icons.assignment),
                            RadioListTile<ReportType>(
                              title: const Text('Report Now'),
                              subtitle: const Text(
                                'Use current date, time, and location.',
                              ),
                              value: ReportType.reportNow,
                              groupValue: _reportType,
                              onChanged: (v) async {
                                if (v == null) return;
                                setState(() => _reportType = v);
                                _lateReason.clear();
                                _setDateTime();
                                await _getLocation();
                              },
                            ),
                            RadioListTile<ReportType>(
                              title: const Text('Late Report'),
                              subtitle: const Text(
                                'Report an earlier incident.',
                              ),
                              value: ReportType.lateReport,
                              groupValue: _reportType,
                              onChanged: (v) {
                                if (v == null) return;
                                setState(() => _reportType = v);
                                _date.clear();
                                _time.clear();
                                _location.clear();
                              },
                            ),
                            if (_reportType == ReportType.lateReport)
                              TextFormField(
                                controller: _lateReason,
                                maxLines: 3,
                                decoration: _input(
                                  'Reason for Late Report',
                                  Icons.edit_note,
                                ),
                                validator: (v) => v == null || v.trim().isEmpty
                                    ? 'Please provide a reason.'
                                    : null,
                              ),
                            const Divider(height: 30),
                            _header('Incident Details', Icons.gavel),
                            TextFormField(
                              controller: _body,
                              textCapitalization: TextCapitalization.characters,
                              decoration: _input(
                                'Tricycle Body Number',
                                Icons.local_taxi,
                                hint: 'e.g. VGN-1234',
                                suffix: _searching
                                    ? const Padding(
                                        padding: EdgeInsets.all(12),
                                        child: SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                          ),
                                        ),
                                      )
                                    : null,
                              ),
                              onChanged: _lookupDriver,
                              validator: (v) => v == null || v.trim().isEmpty
                                  ? 'Please enter body number'
                                  : _bodyError.isEmpty
                                  ? null
                                  : _bodyError,
                            ),
                            const SizedBox(height: 16),
                            DropdownButtonFormField<String>(
                              value: _selectedItem,
                              decoration: _input(
                                'Nature of Complaint',
                                Icons.report,
                              ),
                              items: items
                                  .map(
                                    (e) => DropdownMenuItem(
                                      value: e,
                                      child: Text(e),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (v) =>
                                  setState(() => _selectedItem = v),
                              validator: (v) =>
                                  v == null ? 'Please select complaint' : null,
                            ),
                            const SizedBox(height: 16),
                            TextFormField(
                              controller: _driver,
                              readOnly: true,
                              decoration: _input(
                                'Driver Name',
                                Icons.person,
                                hint: 'Automatically retrieved',
                              ),
                              validator: (v) => v == null || v.trim().isEmpty
                                  ? 'Enter a valid body number first.'
                                  : null,
                            ),
                            const SizedBox(height: 16),
                            TextFormField(
                              controller: _location,
                              readOnly: true,
                              onTap: _reportType == ReportType.lateReport
                                  ? _pickLocation
                                  : null,
                              decoration: _input(
                                'Incident Location',
                                Icons.location_on,
                                hint: 'Tap to pinpoint location',
                                suffix: Icon(
                                  Icons.map,
                                  color: _locating ? Colors.grey : Colors.green,
                                ),
                              ),
                              validator: (v) => v == null || v.isEmpty
                                  ? 'Please pinpoint location'
                                  : null,
                            ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                _DateField(
                                  controller: _date,
                                  onTap: _pickDate,
                                  label: 'Incident Date',
                                ),
                                const SizedBox(width: 12),
                                _DateField(
                                  controller: _time,
                                  onTap: _pickTime,
                                  label: 'Incident Time',
                                  icon: Icons.access_time,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _header(
                              'Evidence Attachment (Optional)',
                              Icons.camera_alt,
                            ),
                            const Text(
                              'Add a photo of the incident or fare receipt.',
                              style: TextStyle(color: Colors.black54),
                            ),
                            const SizedBox(height: 16),
                            if (_image == null)
                              Row(
                                children: [
                                  Expanded(
                                    child: OutlinedButton.icon(
                                      onPressed: () =>
                                          _pickImage(ImageSource.camera),
                                      icon: const Icon(
                                        Icons.camera_alt,
                                        color: Colors.green,
                                      ),
                                      label: const Text('Camera'),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: OutlinedButton.icon(
                                      onPressed: () =>
                                          _pickImage(ImageSource.gallery),
                                      icon: const Icon(
                                        Icons.image,
                                        color: Colors.green,
                                      ),
                                      label: const Text('Gallery'),
                                    ),
                                  ),
                                ],
                              )
                            else
                              Stack(
                                children: [
                                  Container(
                                    height: 200,
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(12),
                                      image: DecorationImage(
                                        image: FileImage(_image!),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    top: 8,
                                    right: 8,
                                    child: CircleAvatar(
                                      backgroundColor: Colors.black54,
                                      child: IconButton(
                                        onPressed: () =>
                                            setState(() => _image = null),
                                        icon: const Icon(
                                          Icons.close,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            _header(
                              'Complainant Information',
                              Icons.assignment_ind,
                            ),
                            if (_loadingProfile)
                              const Padding(
                                padding: EdgeInsets.only(bottom: 16),
                                child: Row(
                                  children: [
                                    SizedBox(
                                      width: 18,
                                      height: 18,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.green,
                                      ),
                                    ),
                                    SizedBox(width: 10),
                                    Text('Loading your profile...'),
                                  ],
                                ),
                              ),
                            TextFormField(
                              controller: _name,
                              readOnly: true,
                              decoration: _input(
                                'Full Name',
                                Icons.badge,
                                hint: 'Automatically from your account',
                              ),
                              validator: (v) => v == null || v.trim().isEmpty
                                  ? 'Name could not be loaded.'
                                  : null,
                            ),
                            const SizedBox(height: 16),
                            TextFormField(
                              controller: _address,
                              decoration: _input(
                                'Home Address (Optional)',
                                Icons.home,
                                hint: 'Optional',
                              ),
                            ),
                            const SizedBox(height: 16),
                            TextFormField(
                              controller: _contact,
                              readOnly: true,
                              keyboardType: TextInputType.phone,
                              decoration: _input(
                                'Contact Number',
                                Icons.phone,
                                hint: 'Automatically from your account',
                              ),
                              validator: (v) => v == null || v.trim().isEmpty
                                  ? 'Contact number could not be loaded.'
                                  : null,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    ElevatedButton.icon(
                      onPressed: _loadingProfile || _uploading ? null : _submit,
                      icon: const Icon(Icons.send, color: Colors.white),
                      label: const Text(
                        'SUBMIT OFFENSE REPORT',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        minimumSize: const Size(double.infinity, 56),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
    );
  }
}

class _DateField extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onTap;
  final String label;
  final IconData icon;
  const _DateField({
    required this.controller,
    required this.onTap,
    required this.label,
    this.icon = Icons.calendar_today,
  });
  @override
  Widget build(BuildContext context) => Expanded(
    child: TextFormField(
      controller: controller,
      readOnly: true,
      onTap: onTap,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.green),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      ),
      validator: (v) => v == null || v.isEmpty ? 'Required' : null,
    ),
  );
}

class IncidentLocationPicker extends StatefulWidget {
  const IncidentLocationPicker({super.key});
  @override
  State<IncidentLocationPicker> createState() => _IncidentLocationPickerState();
}

class _IncidentLocationPickerState extends State<IncidentLocationPicker> {
  final _map = MapController();
  LatLng _center = const LatLng(17.5744, 120.3893);
  bool _loading = true;
  @override
  void initState() {
    super.initState();
    _getPosition();
  }

  Future<void> _getPosition() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (mounted) setState(() => _loading = false);
        return;
      }
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied)
        p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied ||
          p == LocationPermission.deniedForever) {
        if (mounted) setState(() => _loading = false);
        return;
      }
      final x = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      if (mounted)
        setState(() {
          _center = LatLng(x.latitude, x.longitude);
          _loading = false;
        });
    } catch (e) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text(
        'Pinpoint Incident Location',
        style: TextStyle(color: Colors.white),
      ),
      backgroundColor: Colors.green,
      iconTheme: const IconThemeData(color: Colors.white),
    ),
    body: _loading
        ? const Center(child: CircularProgressIndicator(color: Colors.green))
        : Stack(
            children: [
              FlutterMap(
                mapController: _map,
                options: MapOptions(
                  initialCenter: _center,
                  initialZoom: 16.5,
                  onPositionChanged: (p, _) {
                    if (p.center != null) _center = p.center!;
                  },
                ),
                children: [
                  TileLayer(
                    urlTemplate:
                        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.rtoda.complaint_desk_app',
                  ),
                ],
              ),
              const Center(
                child: Padding(
                  padding: EdgeInsets.only(bottom: 36),
                  child: Icon(
                    Icons.location_pin,
                    size: 50,
                    color: Colors.redAccent,
                  ),
                ),
              ),
              Positioned(
                bottom: 24,
                left: 24,
                right: 24,
                child: ElevatedButton.icon(
                  onPressed: () => Navigator.pop(context, _center),
                  icon: const Icon(
                    Icons.check_circle_outline,
                    color: Colors.white,
                  ),
                  label: const Text(
                    'CONFIRM INCIDENT LOCATION',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
            ],
          ),
  );
}
