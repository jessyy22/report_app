import 'dart:convert';
import 'package:http/http.dart' as http;

class ReverseGeocodingService {
  static const String _userAgent = "RTODA-FareCalculator/1.0";

  Future<String?> getBarangay({
    required double latitude,
    required double longitude,
  }) async {
    try {
      final url = Uri.parse(
        "https://nominatim.openstreetmap.org/reverse"
        "?format=jsonv2"
        "&lat=$latitude"
        "&lon=$longitude"
        "&addressdetails=1",
      );

      final response = await http.get(
        url,
        headers: {"User-Agent": _userAgent, "Accept": "application/json"},
      );

      if (response.statusCode != 200) {
        return null;
      }

      final data = jsonDecode(response.body);

      if (data["address"] == null) {
        return null;
      }

      final address = data["address"];

      // Try several possible keys used by OpenStreetMap
      String? barangay =
          address["village"] ??
          address["suburb"] ??
          address["city_district"] ??
          address["neighbourhood"] ??
          address["hamlet"] ??
          address["quarter"];

      if (barangay == null) {
        return null;
      }

      barangay = barangay.trim();

      print("========== Reverse Geocoding ==========");
      print(address);
      print("Detected Barangay: $barangay");
      print("=======================================");

      return barangay;
    } catch (e) {
      print("Reverse Geocoding Error: $e");
      return null;
    }
  }
}
